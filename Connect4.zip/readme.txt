Alan Chai
● Corona
My thought process on the evaluation() method was that the tiles on the edge should be weighted less than the tiles on the center. I thought that this placement of the tiles should also be weighted the same as the actual score of the board. As a result, lower values were placed on tiles that were further away from the center. The number of steps squared(no diagonal steps) was subtracted from the current score.
Since the board can be even or odd, the even edges of boards will be off center. This should not matter too much since both sides are of equivalent value. Since the points are squared and the placement is not, the evaluation function should prioritize obtaining points over placement within the board.

This function is effective given only the state of the board, and being unable to check any other boards. This makes the computer prioritize centralized areas where there are more options to create longer extensions. 

'your_test_2' is an empty 3 by 3 board meant to test whether the evaluation was finding the correct value based on the placed tiles. 

'writeup_1' was changed to test whether at depth 1, the AI goes for placement despite them having the same point value


There does not appear to be any bugs for the AI
Note: I used the wikipedia page for alpha beta pruning and saw the pseudo-code